import React from 'react';
import { View, Text, StatusBar, Linking, Pressable } from 'react-native';

export function Ajuda() {
    const info = 'https://www.varginha.cefetmg.br/informatica/';
    const contato = 'https://www.varginha.cefetmg.br/fale-conosco/';
    const site = 'https://www.varginha.cefetmg.br/';
    return (
        <View style={{flex: 1, backgroundColor: 'red'}}>
            <Pressable onPress={()=> Linking.openURL(info)}>
                <Text>Informações sobre o curso</Text>
            </Pressable>
            <Pressable onPress={()=> Linking.openURL(contato)}>
                <Text>Entre em Contato</Text>
            </Pressable>
            <Pressable onPress={()=> Linking.openURL(site)}>
                <Text>Site Oficial</Text>
            </Pressable>
            <StatusBar />
        </View>
    )
}
