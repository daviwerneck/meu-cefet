import React, { useState } from 'react';
import { View, TextInput, Text, StatusBar, Button, StyleSheet } from 'react-native';

export function Inicio({ navigation }: any) {
    const [nome, setNome] = useState ("")

    function EnviarNome(){
        navigation.navigate('Horários', {
            aluno: nome
        })
    }

    return (
        <View style={{flex: 1}}>
            <Text style={{flex: 1}}>Meu CEFET-MG</Text>
            <TextInput 
                placeholder="Insira seu nome..."
                value={nome}
                onChangeText={setNome}
            />
            <Button 
            title='Enviar'
            onPress={EnviarNome}/>
            <StatusBar />
        </View>
    )
}
