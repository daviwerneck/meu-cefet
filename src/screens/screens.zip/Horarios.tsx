import React from 'react';
import { View, Text, StatusBar, StyleSheet, FlatList } from 'react-native';

// Define uma interface para o item do seu cronograma para garantir a segurança de tipo
interface ScheduleItem {
  id: string;
  time: string;
  title: string;
  location?: string; // Propriedade opcional
}

export function Horarios({ route }: any) {
  const { aluno = 'aluno', cidade = 'Varginha - MG' } = route?.params || {};
  const valor = ( aluno !== '') ? aluno : "aluno";

  // Dados de cronograma de exemplo
  const scheduleData: ScheduleItem[] = [
    { id: '1', time: '08:00 AM', title: 'Aula de Matemática', location: 'Sala 101' },
    { id: '2', time: '10:00 AM', title: 'Reunião de Projeto', location: 'Laboratório B' },
    { id: '3', time: '12:00 PM', title: 'Almoço' },
    { id: '4', time: '02:00 PM', title: 'Aula de Português', location: 'Sala 203' },
    { id: '5', time: '04:00 PM', title: 'Exercício Físico', location: 'Academia' },
  ];

  // Função de renderização para cada item do cronograma
  const renderScheduleItem = ({ item }: { item: ScheduleItem }) => (
    <View>
      <Text>{item.time}</Text>
      <View>
        <Text>{item.title}</Text>
        {item.location && <Text>{item.location}</Text>}
      </View>
    </View>
  );

  return (
    <View>
      <StatusBar />
      <Text>Cidade: {cidade}</Text>
      <Text>Aqui está seu cronograma, {valor}!</Text>

      {/* Usando FlatList para renderização eficiente de listas longas */}
      <FlatList
        data={scheduleData}
        renderItem={renderScheduleItem}
        keyExtractor={(item) => item.id}
        
        ListEmptyComponent={<Text>Nenhum horário disponível no momento.</Text>}
      />
    </View>
  );
}

